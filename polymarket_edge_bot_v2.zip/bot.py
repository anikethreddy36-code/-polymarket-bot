import os, time, json
from pathlib import Path
from datetime import datetime, timezone
import requests
from dotenv import load_dotenv

load_dotenv()
HOST=os.getenv("CLOB_API_URL","https://clob.polymarket.com")
START_BALANCE=float(os.getenv("START_BALANCE","100000"))
MIN_EDGE=float(os.getenv("MIN_EDGE","0.08"))
HIGH_UPSIDE_EDGE=float(os.getenv("HIGH_UPSIDE_EDGE","0.15"))
NORMAL_RISK_PCT=min(float(os.getenv("NORMAL_RISK_PCT","0.02")),0.03)
MAX_LOSS_PCT=min(float(os.getenv("MAX_LOSS_PCT","0.10")),0.10)
DAILY_STOP_PCT=min(float(os.getenv("DAILY_STOP_PCT","0.05")),0.05)
MIN_LIQUIDITY=float(os.getenv("MIN_LIQUIDITY","500"))
SCAN_SECONDS=int(os.getenv("SCAN_SECONDS","30"))
LIVE_TRADING=os.getenv("LIVE_TRADING","false").lower()=="true"
LIVE_CONFIRM=os.getenv("LIVE_CONFIRM","false").lower()=="true"
STATE=Path("bot_state.json")

def load_state():
    if STATE.exists():
        try:return json.loads(STATE.read_text())
        except:pass
    s={"balance":START_BALANCE,"peak_balance":START_BALANCE,"trades":0,"wins":0,"pnl":0.0,"day_start":START_BALANCE}
    STATE.write_text(json.dumps(s,indent=2)); return s

def api(path,params=None):
    r=requests.get(HOST+path,params=params,timeout=15); r.raise_for_status(); return r.json()

def tokens(m):
    x=m.get("tokens") or m.get("clobTokenIds") or []
    if isinstance(x,str):
        try:x=json.loads(x)
        except:x=[x]
    return x

def book(token):
    try:
        b=api("/book",{"token_id":str(token)})
        bids=b.get("bids",[]); asks=b.get("asks",[])
        bid=max((float(x["price"]) for x in bids),default=None)
        ask=min((float(x["price"]) for x in asks),default=None)
        if bid is None or ask is None or ask<=bid:return None
        bs=sum(float(x.get("size",0)) for x in bids); ass=sum(float(x.get("size",0)) for x in asks)
        return bid,ask,bs,ass
    except:return None

def category(q):
    q=q.lower()
    groups={
      "CRYPTO":["bitcoin","btc","ethereum","eth","solana","crypto"],
      "SPORTS":["nba","nfl","football","soccer","tennis","ufc","f1","cricket"],
      "POLITICS":["trump","election","president","senate","congress","governor"],
      "ECONOMICS":["fed","inflation","cpi","jobs","unemployment","interest rate"],
      "ENTERTAINMENT":["movie","oscar","grammy","music","celebrity"]
    }
    for k,words in groups.items():
        if any(w in q for w in words):return k
    return "OTHER"

def scan_market(m):
    ts=tokens(m)
    if not ts:return None
    b=book(ts[0])
    if not b:return None
    bid,ask,bs,ass=b
    liq=min(bs,ass)
    if liq<MIN_LIQUIDITY or ask-bid>0.04:return None
    imbalance=(bs-ass)/(bs+ass) if bs+ass else 0
    fair=max(.02,min(.98,(bid+ask)/2 + .04*imbalance))
    edge=fair-ask
    if edge<MIN_EDGE:return None
    q=m.get("question") or m.get("title") or "Unknown"
    return {"question":q,"category":category(q),"entry":ask,"fair":fair,"edge":edge,
            "liquidity":liq,"bucket":"HIGH-UPSIDE" if edge>=HIGH_UPSIDE_EDGE else "STANDARD"}

def main():
    s=load_state()
    print("POLYMARKET EDGE BOT — ALL CATEGORIES")
    print("Mode:", "LIVE" if LIVE_TRADING and LIVE_CONFIRM else "PAPER")
    print("Unlimited theoretical upside: ENABLED")
    print("Normal risk: 1–3% | Absolute loss ceiling: 10% | Daily stop: 5%")
    while True:
        try:
            if s["balance"]<=s["day_start"]*(1-DAILY_STOP_PCT):
                print("DAILY STOP HIT — HALTED"); break
            data=api("/markets",{"active":"true"})
            markets=data.get("data",[]) if isinstance(data,dict) else data
            best=None
            for m in markets[:500]:
                c=scan_market(m)
                if c and (best is None or c["edge"]>best["edge"]):best=c
            if best:
                risk=min(MAX_LOSS_PCT,max(.01,min(.03,best["edge"]*.20)))
                print(f'[{datetime.now().strftime("%H:%M:%S")}] {best["category"]}/{best["bucket"]} | {best["question"][:70]}')
                print(f'  entry={best["entry"]:.3f} fair={best["fair"]:.3f} edge={best["edge"]*100:.1f}pp liquidity={best["liquidity"]:.0f}')
                print(f"  proposed risk={risk*100:.2f}%")
                s["trades"]+=1; STATE.write_text(json.dumps(s,indent=2))
                print("  PAPER SIGNAL — live execution remains locked.")
            else: print(f'[{datetime.now().strftime("%H:%M:%S")}] No qualifying edge.')
            time.sleep(SCAN_SECONDS)
        except KeyboardInterrupt:break
        except Exception as e:
            print("Scanner error:",e); time.sleep(SCAN_SECONDS)

if __name__=="__main__":main()
