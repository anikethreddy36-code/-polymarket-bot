import json
from pathlib import Path
import streamlit as st
st.set_page_config(page_title="Polymarket Edge Bot",layout="wide")
st.title("Polymarket Edge Bot")
st.caption("All-market scanner • unlimited theoretical upside • strict downside control")
p=Path("bot_state.json")
s=json.loads(p.read_text()) if p.exists() else {"balance":100000,"peak_balance":100000,"trades":0,"wins":0,"pnl":0}
balance=float(s.get("balance",100000)); start=100000
pnl=float(s.get("pnl",balance-start)); ret=pnl/start*100
trades=int(s.get("trades",0)); wins=int(s.get("wins",0))
dd=(float(s.get("peak_balance",balance))-balance)/float(s.get("peak_balance",balance))*100
a,b,c,d=st.columns(4)
a.metric("Balance",f"₹{balance:,.0f}"); b.metric("Net P&L",f"₹{pnl:,.0f}",f"{ret:+.2f}%")
c.metric("Trades",trades); d.metric("Win rate",f"{(wins/trades*100 if trades else 0):.2f}%")
e,f,g=st.columns(3); e.metric("Max drawdown",f"{dd:.2f}%"); f.metric("Normal risk","1–3%"); g.metric("Max loss/trade","10%")
st.divider()
st.subheader("Market universe")
st.write("₿ Crypto • 🏀 Sports • 📰 Politics/News • 💰 Economics • 🎬 Entertainment • Other")
st.info("1000x+ theoretical payoff markets are allowed. The bot does not cap upside. Risk, liquidity, spread, and daily-loss controls remain active.")
st.warning("LIVE EXECUTION IS LOCKED until paper performance and account/API verification are completed.")
