# Polymarket Edge Bot v2

All-category scanner: crypto/BTC, sports, politics/news, economics, entertainment and other active markets.

1000x+ theoretical payoff is not capped. Downside controls remain: 1–3% normal risk, 10% absolute maximum-loss ceiling, 5% daily stop, liquidity/spread filters.

Live execution is intentionally locked. Validate paper performance first.

Run:
python -m venv .venv
pip install -r requirements.txt
python bot.py

Dashboard:
streamlit run dashboard.py

Never paste a seed phrase/private key/API secret into chat.
